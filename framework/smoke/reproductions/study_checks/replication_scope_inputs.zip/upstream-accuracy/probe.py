# ABOUTME: Times real upstream gradient probes on the unreduced glycine operator.
# ABOUTME: Separates native restricted and full pool sizes from an explicitly sampled first-screen timing.
from pathlib import Path
from hashlib import sha256
import json
import sys
from time import perf_counter
from statistics import median, mean
import numpy as np
from core.hamiltonian_loader import Molecule, QubitHamiltonian
from algorithms.vqe_qubit_adapt import QubitAdaptVQE
from experiments._common import make_backend_config
from experiments.accuracy_vs_params import _build_argparser
from threadpoolctl import threadpool_info
input_path=Path(sys.argv[1])
assert sha256(input_path.read_bytes()).hexdigest()=='3f1095c4864bc97943201b383918440b45b7acebd0025d2f70b2b06af6b3a9ec'
with np.load(input_path,allow_pickle=False) as p:
    h=QubitHamiltonian(Molecule(**json.loads(str(p['molecule']))),p['coefficients'],p['pauli_strings'].tolist(),int(p['n_qubits']),len(p['coefficients']))
expected_path=Path(__file__).resolve().parent/'framework'
assert Path(sys.modules['algorithms.vqe_qubit_adapt'].__file__).resolve().is_relative_to(expected_path)
print(json.dumps(dict(input=str(input_path),qubits=h.n_qubits,terms=h.n_terms,electrons=h.molecule.n_electrons,available_accuracy_cli_flags=sorted(_build_argparser()._option_string_actions),native_thread_counts=[x['num_threads'] for x in threadpool_info()])),flush=True)
for restricted in (True,False):
    solver=QubitAdaptVQE(h,use_restricted_pool=restricted,max_gradient_candidates=24,random_seed=42,backend_config=make_backend_config(h.n_qubits))
    solver.build_ansatz()
    solver._noncommuting_ops=solver._noncommuting_pool_indices()
    data=[]
    native=solver.cost_function
    def timed(theta):
        s=perf_counter(); result=native(theta)
        data.append(dict(operator=solver.selected_operators[-1],seconds=perf_counter()-s,energy=float(result)))
        return result
    solver.cost_function=timed
    s=perf_counter(); grads=solver._compute_gradients(); wall=perf_counter()-s
    assert len(data)==48 and np.isfinite(grads).all()
    print(json.dumps(dict(restricted=restricted,pool=len(solver.operator_pool),eligible=len(solver._noncommuting_ops),subset_candidates=24,seconds=wall,mean_seconds=mean([v['seconds'] for v in data]),median_seconds=median([v['seconds'] for v in data]),outcome=grads.max(),records=data)),flush=True)
