# ABOUTME: Times the current HE circuit with the measured May operator, angles and zero-state preparation.
# ABOUTME: Compares all native energies at the control angles against the May-source run.
from pathlib import Path
from hashlib import sha256
from time import perf_counter
import json
import numpy as np
from core.hamiltonian_loader import Molecule, QubitHamiltonian
from experiments._common import build_vqe, make_backend_config, NOISE_ALGORITHMS, sample_initial_parameters
from experiments.noise_resilience import _noise_objective
p=Path(__file__).parent
source=[json.loads(x) for x in (p/'timings.jsonl').read_text().splitlines()]
op=p/'measured_glycine.npz'
assert sha256(op.read_bytes()).hexdigest()==source[0]['operator_sha256']
with np.load(op) as v:
    terms=list(v['terms']);n=int(v['n_qubits']);coeff=v['coefficients']
h=QubitHamiltonian(Molecule('gly','glycine',n,len(terms),-279.137662914624,'recorded-in-measured_glycine.npz'),coeff,terms,n,len(terms))
for channel in ('depolarizing','phaseflip','amplitude_damping'):
    backend=make_backend_config(n,channel,.01)
    s=build_vqe(h,algorithm='hardware_efficient_vqe',n_layers=2,rotation_gates='RY_RZ',prepare_hf=False,backend_config=backend,optimizer='COBYLA',max_iterations=150,convergence_threshold=1e-10,random_seed=42,supported_algorithms=NOISE_ALGORITHMS)
    cost=_noise_objective(s.cost_function,backend)
    theta=sample_initial_parameters(36,strategy='small_random',rng=np.random.default_rng(42))
    for i in range(3):
        x=theta.copy()
        if i: x[i-1]+=1.
        orig=next(r for r in source if r.get('channel')==channel and r.get('sample')==i)
        assert orig['parameters_sha256']==sha256(x.tobytes()).hexdigest()
        t=perf_counter();energy=cost(x);dt=perf_counter()-t
        print(json.dumps(dict(channel=channel,sample=i,seconds=dt,energy=float(energy).hex(),may_energy=orig['value'],same=orig['value']==float(energy).hex(),delta=energy-float.fromhex(orig['value'])),allow_nan=False),flush=True)
