# ABOUTME: Repeats the May-source throughput measurement and checks the current circuit at the saved angles.
# ABOUTME: Runs the two versions against one frozen glycine operator with one native thread per library.
set -eu
root=/Users/ethankuntz/Documents/ChatGPT/VQE_Sanskriti
pilot=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$pilot/framework/datasets2/gly"
git -C "$root" archive 2264f87 framework/active_space_truncation framework/algorithms framework/contextual_subspace framework/core framework/experiments framework/config.py | tar -x -C "$pilot"
cp "$root/framework/smoke/geometries/gly/gly.h5" "$pilot/framework/datasets2/gly/gly.h5"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 MPLCONFIGDIR=/tmp/vqe-smoke-mpl MPLBACKEND=Agg
PYTHONPATH="$pilot/framework" "$root/framework/.venv/bin/python" "$pilot/pilot.py" > "$pilot/pilot.log" 2> "$pilot/pilot.stderr"
rg '^\{' "$pilot/pilot.log" > "$pilot/timings.jsonl"
PYTHONPATH="$root/framework" "$root/framework/.venv/bin/python" "$pilot/current_probe.py" > "$pilot/current_timings.jsonl" 2> "$pilot/current_probe.stderr"
