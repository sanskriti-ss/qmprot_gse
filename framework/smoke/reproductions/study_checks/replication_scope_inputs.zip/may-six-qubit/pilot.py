# ABOUTME: Times distinct noisy energies in the May six-qubit glycine hardware-efficient ansatz.
# ABOUTME: Persists the ordered operator and records per-channel values, timings and native circuit details.
from hashlib import sha256
import json
import platform
from pathlib import Path
from time import perf_counter
import numpy as np
import pennylane as qml
from experiments._common import build_vqe, load_small_hamiltonian, make_backend_config, sample_initial_parameters
from experiments.noise_resilience import DEFAULT_NOISE_MODELS

root = Path(__file__).parent
def emit(**record):
    print(json.dumps(record,allow_nan=False,default=str),flush=True)
t = perf_counter()
m = load_small_hamiltonian(molecule='gly', basis='sto-3g', cs_target_qubits=6)
h = m.hamiltonian
operator = root / 'measured_glycine.npz'
np.savez_compressed(operator, terms=np.asarray(h.pauli_strings), coefficients=np.asarray(h.coefficients), n_qubits=h.n_qubits)
emit(source='2264f87', platform=platform.platform(), pennylane=qml.__version__,numpy=np.__version__, geometry_sha256=sha256((root/'framework/datasets2/gly/gly.h5').read_bytes()).hexdigest(), operator_sha256=sha256(operator.read_bytes()).hexdigest(), terms=h.n_terms,active=m.n_qubits_active,qubits=h.n_qubits, preparation_seconds=perf_counter()-t)
assert h.n_qubits == 6 and h.n_terms > 10
for channel in DEFAULT_NOISE_MODELS:
    t=perf_counter()
    solver=build_vqe(h,algorithm='hardware_efficient_vqe', n_layers=2,backend_config=make_backend_config(6,channel,.01),optimizer='COBYLA',max_iterations=150,convergence_threshold=1e-10,random_seed=42)
    emit(channel=channel,build_seconds=perf_counter()-t,n_parameters=solver.n_parameters,gates=solver.rotation_gates)
    assert solver.n_parameters==36
    initial=sample_initial_parameters(36,strategy='small_random',rng=np.random.default_rng(42))
    for sample in range(3):
        theta=initial.copy()
        if sample: theta[sample-1]+=1.
        t=perf_counter();e=solver.cost_function(theta);seconds=perf_counter()-t
        emit(channel=channel,sample=sample,value=float(e).hex(),seconds=seconds,parameters_sha256=sha256(theta.tobytes()).hexdigest())
