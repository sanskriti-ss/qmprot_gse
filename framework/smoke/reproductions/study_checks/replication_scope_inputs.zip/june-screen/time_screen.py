# ABOUTME: Times native displaced energy evaluations from the historical Qubit-ADAPT screen.
# ABOUTME: Records the historical pool and input, angles, outputs and complete timing sample.
import sys,json,time,pathlib,platform,statistics,hashlib
from dataclasses import fields
import numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent/'framework'))
from algorithms.vqe_qubit_adapt import QubitAdaptVQE
from core.hamiltonian_loader import QubitHamiltonian,Molecule
from core.backend_manager import BackendConfig
p=pathlib.Path('results/profiling/semantic-acceptance/full-budget-gly/gly/inputs/gly.npz'); raw=np.load(p); desc=json.loads(str(raw['molecule'])); m=Molecule(**{k:desc[k] for k in desc.keys() & {f.name for f in fields(Molecule)}}); h=QubitHamiltonian(m,raw['coefficients'],raw['pauli_strings'].tolist(),int(raw['n_qubits']),len(raw['coefficients'])); q=QubitAdaptVQE(h,backend_config=BackendConfig.statevector(n_qubits=h.n_qubits),optimizer='COBYLA',max_iterations=500,random_seed=42);q.build_ansatz(); viable=q._prescreen_pool(); rows=[]
for idx in np.linspace(0,len(viable)-1,8,dtype=int):
 q.selected_operators=[viable[idx]]
 for theta in (1e-5,-1e-5):
  begin=time.perf_counter(); energy=q.cost_function(np.array([theta])); rows.append(dict(id=viable[idx],theta=theta,seconds=time.perf_counter()-begin,energy=float(energy)))
print(json.dumps({'commit':'49f1c5c','input':str(p),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'qubits':h.n_qubits,'terms':h.n_terms,'pool':len(q.operator_pool),'viable':len(viable),'samples':rows,'median_seconds':statistics.median(r['seconds'] for r in rows),'platform':platform.platform()},indent=2))
