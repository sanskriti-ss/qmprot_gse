# ABOUTME: Samples the upstream gradient study's unmodified noiseless bound QNode on frozen glycine.
# ABOUTME: Scales native warm objective costs by its default depths, probes, trials and steps.
from pathlib import Path
import sys,time,statistics,json,hashlib,platform
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'framework'))
from core.hamiltonian_loader import Molecule,QubitHamiltonian
from experiments._common import build_vqe,make_backend_config
from experiments.barren_plateau import DEFAULT_LAYERS,DEFAULT_GRADIENT_STEPS,DEFAULT_MAX_GRADIENT_PROBES,_probe_indices
p=Path('smoke/reproductions/layered_vqe/contextual_gly.npz'); d=np.load(p); m=Molecule(**json.loads(str(d['molecule']))); s=d['initial_state']; h=QubitHamiltonian(m,d['coefficients'],d['pauli_strings'].tolist(),int(d['n_qubits']),len(d['coefficients']),s if s.size else None); rng=np.random.default_rng(42); rec={}; part_a=part_b=0.
for depth in DEFAULT_LAYERS:
 v=build_vqe(h,algorithm='hardware_efficient_vqe',n_layers=depth,backend_config=make_backend_config(h.n_qubits),optimizer='COBYLA',max_iterations=1,random_seed=42)
 n=v.n_parameters; times=[]; energies=[]
 for th in rng.uniform(-1,1,(8,n)):
  t=time.perf_counter();energies.append(float(v.cost_fn(th)));times.append(time.perf_counter()-t)
 warm=statistics.median(times[1:]); count_a=3*30*2*len(_probe_indices(n,None,DEFAULT_MAX_GRADIENT_PROBES)); count_b=(1+DEFAULT_GRADIENT_STEPS*(2*n+1))*15 if depth==6 else 0; part_a+=warm*count_a;part_b+=warm*count_b;rec[depth]=dict(parameters=n,seconds=times,energy=energies,part_a_evals=count_a,part_b_evals=count_b,warm_median=warm)
print(json.dumps(dict(revision='6e4bea1',host=platform.platform(),molecule=str(d['dataset']),qubits=h.n_qubits,terms=h.n_terms,source_fixture=str(p),input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),data=rec,projected_forward_seconds_per_molecule=dict(part_a=part_a,part_b=part_b),five_molecule_hours=5*(part_a+part_b)/3600,nineteen_molecule_hours=19*(part_a+part_b)/3600),indent=2))
