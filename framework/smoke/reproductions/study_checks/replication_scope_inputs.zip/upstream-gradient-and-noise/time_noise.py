# ABOUTME: Times full upstream noise objective calls on a frozen eight-qubit glycine operator.
# ABOUTME: Uses production HE rotations and seed with one nonzero channel strength per case.
from pathlib import Path
import sys,time,json,hashlib,platform
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'framework'))
from core.hamiltonian_loader import Molecule,QubitHamiltonian
from experiments._common import build_vqe,make_backend_config,sample_initial_parameters
from experiments.noise_resilience import _algo_kwargs
p=Path('smoke/reproductions/layered_vqe/contextual_gly.npz');d=np.load(p);m=Molecule(**json.loads(str(d['molecule'])));s=d['initial_state'];h=QubitHamiltonian(m,d['coefficients'],d['pauli_strings'].tolist(),int(d['n_qubits']),len(d['coefficients']),s if s.size else None)
print(json.dumps(dict(commit='6e4bea1',host=platform.platform(),fixture=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),qubits=h.n_qubits,terms=h.n_terms)),flush=True)
for model in ('depolarizing','phaseflip','amplitude_damping'):
 v=build_vqe(h,algorithm='hardware_efficient_vqe',n_layers=2,backend_config=make_backend_config(h.n_qubits,model,.01),optimizer='COBYLA',max_iterations=150,random_seed=42,**_algo_kwargs('hardware_efficient_vqe','RY',True)); th=sample_initial_parameters(v.n_parameters,'small_random',np.random.default_rng(42)); q=v.cost_fn;q.construct((th,),{});dev=v.device.target_device; groups,_=dev.batch_transform(q.tape);print(json.dumps(dict(model=model,n_params=v.n_parameters,n_groups=len(groups))),flush=True)
 for i in range(2):
  if i: th[0]+=1
  t=time.perf_counter();e=float(v.cost_function(th));print(json.dumps(dict(model=model,sample=i,energy=e,seconds=time.perf_counter()-t)),flush=True)
