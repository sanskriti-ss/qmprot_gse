# ABOUTME: Runs short historical paper workload samples on a single two-core Modal CPU worker.
# ABOUTME: Restores isolated source revisions and returns every native objective timing.
from pathlib import Path
import json

import modal
from smoke.modal_representative import image

app = modal.App("qmprot-paper-price")
if modal.is_local():
    data = Path(__file__).parent
    for item in ("price_probe.py","june.tgz","may.tgz","gly6.npz","gly12.npz"):
        image = image.add_local_file(data / item, f"/samples/{item}")

@app.function(image=image,cpu=2,memory=4096,timeout=360,retries=0)
def measure():
    from hashlib import sha256
    from time import perf_counter
    import os
    import subprocess
    import sys
    import tarfile
    import tempfile
    source = Path("/samples")
    result = {}
    before = perf_counter()
    for month, filename in (("june","gly12.npz"),("may","gly6.npz")):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive = source / f"{month}.tgz"
            with tarfile.open(archive) as bundle:
                bundle.extractall(root,filter="data")
            env = dict(os.environ, PYTHONPATH=str(root/"framework"), OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",
                       VECLIB_MAXIMUM_THREADS="1",MKL_NUM_THREADS="1",MPLBACKEND="Agg")
            job = subprocess.run([sys.executable,str(source/"price_probe.py"),month,str(source/filename)],
                                 cwd=root/"framework",env=env,capture_output=True,text=True)
            if job.returncode:
                raise RuntimeError(job.stderr[-2500:])
            result[month] = dict(source_sha256=sha256(archive.read_bytes()).hexdigest(), rows=[
                json.loads(line) for line in job.stdout.splitlines() if line.startswith("{")],stdout=job.stdout,stderr=job.stderr)
            print(month, len(result[month]["rows"]), flush=True)
    return dict(workloads=result, worker_seconds=perf_counter()-before)

@app.local_entrypoint()
def main(output: str):
    destination = Path(output)
    if destination.exists():
        raise FileExistsError(destination)
    result = measure.remote()
    with destination.open("x") as out:
        json.dump(result,out,indent=2,allow_nan=False)
        out.write("\n")
