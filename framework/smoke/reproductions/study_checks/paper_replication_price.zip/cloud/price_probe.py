# ABOUTME: Times historical noisy HE and clean Qubit-ADAPT objectives on frozen glycine models.
# ABOUTME: Records measured depths, channels, parameter vectors and native energy results.
from dataclasses import fields
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import json
import sys

import numpy as np

from core.hamiltonian_loader import Molecule, QubitHamiltonian
from experiments._common import make_backend_config


def timed(cost, angles, **case):
    start = perf_counter()
    result = cost(angles)
    print(json.dumps(dict(**case, seconds=perf_counter() - start, energy=float(result).hex(),
                          angles_sha256=sha256(angles.tobytes()).hexdigest())), flush=True)


def noisy(path):
    from experiments._common import build_vqe, sample_initial_parameters
    with np.load(path, allow_pickle=False) as args:
        terms = args["terms"].tolist()
        n = int(args["n_qubits"])
        ham = QubitHamiltonian(Molecule("gly","glycine",n,len(terms),-279.137662914624,"frozen"),
                               args["coefficients"],terms,n,len(terms))
    for channel in ("depolarizing","phaseflip","amplitude_damping"):
        solver = build_vqe(ham, algorithm="hardware_efficient_vqe", n_layers=2,
                           backend_config=make_backend_config(n,channel,.01), optimizer="COBYLA",
                           max_iterations=150, convergence_threshold=1e-10, random_seed=42)
        assert solver.n_parameters == 36 and solver.rotation_gates == "RY_RZ"
        angles = sample_initial_parameters(36,strategy="small_random",rng=np.random.default_rng(42))
        for sample in range(3):
            x = angles.copy()
            if sample:
                x[sample-1] += 1.
            timed(solver.cost_function,x,channel=channel,sample=sample)


def adaptive(path):
    from algorithms.vqe_qubit_adapt import QubitAdaptVQE
    with np.load(path, allow_pickle=False) as args:
        desc = json.loads(str(args["molecule"]))
        molecule = Molecule(**{f.name:desc[f.name] for f in fields(Molecule) if f.name in desc})
        ham = QubitHamiltonian(molecule,args["coefficients"],args["pauli_strings"].tolist(),
                               int(args["n_qubits"]),len(args["coefficients"]))
    solver = QubitAdaptVQE(ham,backend_config=make_backend_config(ham.n_qubits),optimizer="COBYLA",
                           max_iterations=500,random_seed=42)
    solver.build_ansatz()
    pool = solver._prescreen_pool()
    rng = np.random.default_rng(42)
    ordering = rng.permutation(pool).tolist()
    for size in (1,10,50,100):
        angles = rng.uniform(-.35,.35,size=size)
        for candidate in range(3):
            solver.selected_operators = ordering[:size-1] + [ordering[size-1+candidate]]
            for delta in (1e-5,-1e-5):
                x = angles.copy()
                x[-1] = delta
                timed(solver.cost_function,x,depth=size,candidate=candidate,delta=delta)

if __name__ == "__main__":
    fn,filename = sys.argv[1:]
    path = Path(filename)
    print(json.dumps(dict(workload=fn,input_sha256=sha256(path.read_bytes()).hexdigest())),flush=True)
    {"may":noisy,"june":adaptive}[fn](path)
