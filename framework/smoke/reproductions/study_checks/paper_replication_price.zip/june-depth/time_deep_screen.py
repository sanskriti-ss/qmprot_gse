# ABOUTME: Measures the June Qubit-ADAPT energy path at several attained circuit sizes on frozen glycine.
# ABOUTME: Samples fixed test circuits and native probe pairs without asserting the paper selected these operators.
import json, sys, time, platform, statistics
from pathlib import Path
from hashlib import sha256
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'framework'))
from algorithms.vqe_qubit_adapt import QubitAdaptVQE
from core.hamiltonian_loader import QubitHamiltonian,Molecule
from core.backend_manager import BackendConfig
p=Path('results/profiling/semantic-acceptance/full-budget-gly/gly/inputs/gly.npz'); a=np.load(p); h=QubitHamiltonian(Molecule(**json.loads(str(a['molecule']))),a['coefficients'],a['pauli_strings'].tolist(),int(a['n_qubits']),len(a['coefficients'])); q=QubitAdaptVQE(h,backend_config=BackendConfig.statevector(n_qubits=h.n_qubits),optimizer='COBYLA',max_iterations=500,random_seed=42);q.build_ansatz(); viable=q._prescreen_pool();rng=np.random.default_rng(42);ids=rng.permutation(viable);angle=rng.uniform(-np.pi/2,np.pi/2,len(ids));print(json.dumps(dict(source='49f1c5c',input=str(p),input_sha256=sha256(p.read_bytes()).hexdigest(),qubits=h.n_qubits,terms=h.n_terms,viable=len(viable),seed=42,platform=platform.platform(),scope='Non-optimized test circuits; signed shifts in last angle of four candidate pairs per attained length. Source paths are those of June; chosen operators and angles are illustrative.')),flush=True)
for depth in (1,10,50,100):
 rows=[]
 for cand in ids[120:124]:
  q.selected_operators=list(ids[:depth-1])+[cand]
  for delta in (1e-5,-1e-5):
   theta=np.append(angle[:depth-1],delta); t=time.perf_counter(); energy=q.cost_function(theta);dt=time.perf_counter()-t;rows.append(dict(seconds=dt,candidate=int(cand),energy=float(energy),shift=delta))
 print(json.dumps(dict(depth=depth,median_seconds=statistics.median(x['seconds'] for x in rows),samples=rows)),flush=True)
