# ABOUTME: Times the original June initialization gradient panel and one full Bayesian trial.
# ABOUTME: Uses the frozen four-qubit glycine operator and records the native row counts and fit endpoint.
from pathlib import Path
from hashlib import sha256
from statistics import mean
from time import perf_counter
from dataclasses import asdict
import json
import numpy as np
from experiments._common import LoadedHamiltonian
from core.hamiltonian_loader import Molecule,QubitHamiltonian
from experiments.barren_plateau import run_optimization_comparison,measure_gradient_variance
p=Path(__file__).parent/'gly.npz'
with np.load(p) as x:
    mol=Molecule(**json.loads(str(x['molecule'])))
    h=QubitHamiltonian(molecule=mol, coefficients=x['coefficients'],pauli_strings=list(x['pauli_strings']), n_qubits=int(x['n_qubits']),n_terms=len(x['pauli_strings']))
    loaded=LoadedHamiltonian(h,'gly','sto-3g',int(x['n_qubits_active']),int(x['n_qubits']),True,casci_energy=float(x['casci']),hf_energy=float(x['molecular_hf']))
def emit(**d):
    print(json.dumps(d,allow_nan=False,default=str),flush=True)
emit(source='240508a',qubits=h.n_qubits,terms=h.n_terms,input=sha256(p.read_bytes()).hexdigest())
start=perf_counter()
rows=measure_gradient_variance(loaded,algorithm='hardware_efficient_vqe',layers=(1,2,4,8,16),strategies=('near_identity','random_uniform','small_random'),n_samples=30,gradient_index=0,random_seed=42)
emit(study='A',seconds=perf_counter()-start,requested_energies=900,rows=[asdict(r) for r in rows])
start=perf_counter()
rows=run_optimization_comparison(loaded,algorithm='hardware_efficient_vqe',n_layers=16,strategies=('small_random',),n_trials=1,optimizer='BAYESIAN',max_iterations=200,convergence_threshold=1e-10,noise_model=None,noise_strength=0.,random_seed=42)
emit(study='B',seconds=perf_counter()-start,rows=[asdict(r) for r in rows])
