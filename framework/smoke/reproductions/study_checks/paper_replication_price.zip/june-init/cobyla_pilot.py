# ABOUTME: Times a noiseless matched-control COBYLA trial on the frozen six-qubit May glycine operator.
# ABOUTME: Records the callback length separately from the optimizer budget for the historical plot.
from pathlib import Path
from time import perf_counter
import json,numpy as np
from core.hamiltonian_loader import Molecule,QubitHamiltonian
from experiments._common import LoadedHamiltonian
from experiments.barren_plateau import run_optimization_comparison
p=Path('/tmp/qmprot-paper-week-may/measured_glycine.npz')
with np.load(p) as x:
    n=int(x['n_qubits']);terms=list(x['terms']);c=x['coefficients']
h=QubitHamiltonian(Molecule('gly','glycine',n,len(terms),-279.137662914624,'frozen'),c,terms,n,len(terms)); loaded=LoadedHamiltonian(h,'gly','sto-3g',12,n,True)
for cap in (100,150,200):
    start=perf_counter();r=run_optimization_comparison(loaded,algorithm='hardware_efficient_vqe',n_layers=6,strategies=('small_random',),n_trials=1,optimizer='COBYLA',max_iterations=cap,convergence_threshold=1e-10,noise_model=None,noise_strength=0.,random_seed=42)[0]
    print(json.dumps(dict(source='240508a',register=n,terms=len(terms),layers=r.n_layers,params=r.n_parameters,cap=cap,seconds=perf_counter()-start,callbacks=len(r.convergence_history),initial=r.initial_energy,final=r.final_energy)),flush=True)
